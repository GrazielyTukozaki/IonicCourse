import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
})
export class ProductComponent implements OnInit {

  @Input() item;

  constructor() { 
    console.log('contructor', this.item);
  }

  ngOnInit() {
    console.log('ngOninit', this.item);
  }

}
