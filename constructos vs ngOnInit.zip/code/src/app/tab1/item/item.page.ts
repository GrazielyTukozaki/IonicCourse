import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api/api.service';

@Component({
  selector: 'app-item',
  templateUrl: './item.page.html',
  styleUrls: ['./item.page.scss'],
})
export class ItemPage implements OnInit {

  items: any[] = [];

  constructor(public apiService: ApiService) { }

  ngOnInit() {
    console.log('ngOnInit');
    // this.items = this.apiService.getItems();  
    this.getData();
  }

  async getData() {
    try {
      const data = await this.apiService.getItems();
      const val = await this.apiService.checkTotal(data);
      if(val) {
        this.items = data;
      }
      console.log('items value: ', this.items);



      const object1 = {...this.items[0], price: 15, p_code: 12};
      console.log('object1: ', object1);


      // const array1 = [...this.items, {id: 2, name: 'p2'}];
      const array1 = [1,2,3,4];
      const array2 = [1,3,7,8];
      const array3 = [...array1, ...array2, 1, 0,9];
      console.log('array3: ', array3);



    } catch(e) {
      console.error(e);
    }
    
    // this.apiService.getItems().then(data => {
    //   console.log('items: ', data);      
    //   // this.items = data;
    //   this.apiService.checkTotal(data).then(val => {
    //     console.log(val);
    //     if(val) {
    //       this.items = data;
    //     }
    //   }).catch(e => {
    //     console.log(e);
    //   });
    // })
    // .catch(err => {
    //   console.log(err);
    // });
  }

  ionViewWillEnter() {
    console.log('ionViewWillEnter');
  }

  ionViewDidEnter() {
    console.log('ionViewDidEnter');
  }

  ionViewWillLeave() {
    console.log('ionViewWillLeave');
  }

  ionViewDidLeave() {
    console.log('ionViewDidLeave');
  }

  ngOnDestroy() {
    console.log('ngOnDestroy');
  }

}
