import { Component, Input, OnInit } from '@angular/core';
import { Product } from 'src/app/models/product.model';
// import { Product } from 'src/app/interfaces/product.interface';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
})
export class ProductComponent implements OnInit {

  @Input() item: Product;

  constructor() { 
    console.log('contructor', this.item);
  }

  ngOnInit() {
    console.log('ngOninit', this.item);
  }

}
