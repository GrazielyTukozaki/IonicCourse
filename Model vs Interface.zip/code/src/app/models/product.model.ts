export class Product {
    constructor(
        public id: number, 
        public name: string, 
        public description: string, 
        public price: number
    ) {
        this.name += this.id; // this.name = this.name + this.id;
    }
}